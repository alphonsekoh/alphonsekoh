import os
import json
from flask import Flask, request, send_file
from google.oauth2 import service_account
import googleapiclient.discovery
from oauth2client.client import GoogleCredentials
import gspread
import time
import csv

app = Flask(__name__)
credentials = service_account.Credentials.from_service_account_file(filename="hiverlab-xcitech.json")


@app.route('/createProject', methods=['POST'])
def create_project():
    project_name = request.args.get("project_name")

    service = googleapiclient.discovery.build('cloudresourcemanager', 'v1', credentials=credentials)

    timestamp = time.time_ns() / 1000
    stamp_for_id = str(int(timestamp))[-6:]

    project_id = str(project_name).replace(" ", "").strip() + "-" + stamp_for_id

    project_body = {
        "name": project_name,
        "projectId": project_id,
        "parent": {
            "id": "383392057770",
            "type": "folder"
        }
    }

    #response = service.projects().list().execute()
    project = service.projects().create(body=project_body).execute()

    account_id = request.args.get("account_id")
    display_name = request.args.get("display_name")

    formatted_account_id = str(account_id).replace(" ", "").strip().lower()

    service = googleapiclient.discovery.build(
        'iam', 'v1', credentials=credentials)

    my_service_account = service.projects().serviceAccounts().create(
        name='projects/' + project_id,
        body={
            'accountId': formatted_account_id,
            'serviceAccount': {
                'displayName': display_name
            }
        }).execute()

    key = service.projects().serviceAccounts().keys().create(
        name='projects/-/serviceAccounts/' + my_service_account['email'], body={}
    ).execute()

    return {"success": 1, "key": key}


@app.route('/exportCSV')
def export_csv():
    url = request.args.get("spreadsheet_url")
    scope = ['https://spreadsheets.google.com/feeds',
             'https://www.googleapis.com/auth/drive']

    client = gspread.service_account("hiverlab-xcitech.json", scope)
    sheet = client.open_by_url(url)
    worksheet = sheet.worksheets()[0]
    values = worksheet.get_all_values()
    # output_file = 'spreadsheet.csv'
    #
    # with open(output_file, 'w') as f:
    #     writer = csv.writer(f)
    #     writer.writerows(values)
    #
    # f.close()

    return str(values)


@app.route('/createCredentials', methods=['POST'])
def create_service_account():
    project_id = request.args.get("project_id")
    account_id = request.args.get("account_id")
    display_name = request.args.get("display_name")

    formatted_account_id = str(account_id).replace(" ", "").strip().lower()

    service = googleapiclient.discovery.build(
        'iam', 'v1', credentials=credentials)

    my_service_account = service.projects().serviceAccounts().create(
        name='projects/' + project_id,
        body={
            'accountId': formatted_account_id,
            'serviceAccount': {
                'displayName': display_name
            }
        }).execute()

    key = service.projects().serviceAccounts().keys().create(
        name='projects/-/serviceAccounts/' + my_service_account['email'], body={}
    ).execute()

    return {"success": 1, "key": key}
